from ecoliframalpha.main import main  # Import the main function

if __name__ == "__main__":
    main()  